"""
setup_env.py
============
Installs Pygame so you can play Stroop Smash. Run it once, before you play.

The easiest way: open this file in VSCode and press the Run button.
Or type this in the terminal, from the stroop_smash folder:

    Windows:  python setup_env.py
    Mac:      python3 setup_env.py

It asks you to choose one of two ways to install Pygame:

    1. A virtual environment (.venv) inside this folder   <- recommended
    2. Your base Python (the Python you already use)

It's safe to run again: if Pygame is already installed, it won't install it
twice. You never need to change this file.
"""

import os
import shutil
import subprocess
import sys
import sysconfig

GAME_FOLDER = os.path.dirname(os.path.abspath(__file__))
VENV_FOLDER = os.path.join(GAME_FOLDER, ".venv")
REQUIREMENTS = os.path.join(GAME_FOLDER, "requirements.txt")

ON_WINDOWS = (os.name == "nt")
ON_MAC = (sys.platform == "darwin")

if ON_MAC:
    SHORTCUT = "Cmd+Shift+P"
else:
    SHORTCUT = "Ctrl+Shift+P"

LINE = "=" * 64


# ======================================================================
# Small helpers
# ======================================================================

def banner(text):
    print()
    print(LINE)
    print(" " + text)
    print(LINE)


def stop(message):
    """Print a problem and how to fix it, then quit."""
    banner("SETUP DIDN'T FINISH")
    print(message)
    print()
    print("If you're stuck, ask a classmate or your instructor, and show them")
    print("everything this script printed (a screenshot is perfect).")
    print()
    sys.exit(1)


def run_quietly(command):
    """Run a terminal command without showing its output. Returns (worked, output)."""
    env = dict(os.environ, PYGAME_HIDE_SUPPORT_PROMPT="1")
    try:
        result = subprocess.run(command, capture_output=True, text=True, env=env)
    except OSError:
        return False, ""
    return result.returncode == 0, (result.stdout + result.stderr).strip()


def pygame_version(python):
    """Return the Pygame version installed for `python`, or None if it isn't installed."""
    worked, output = run_quietly([python, "-c", "import pygame; print(pygame.version.ver)"])
    if worked and output:
        return output.splitlines()[-1]
    return None


def install_requirements(python):
    """Install everything in requirements.txt for `python`. Returns True if it worked."""
    print()
    print("Installing Pygame. This can take a minute or two...")
    print()
    command = [python, "-m", "pip", "install", "--disable-pip-version-check",
               "-r", REQUIREMENTS]
    result = subprocess.run(command)
    return result.returncode == 0


def running_in_a_venv():
    return sys.prefix != sys.base_prefix


# ======================================================================
# Choosing venv or base
# ======================================================================

def choose_mode():
    """Return "venv" or "base"."""
    # Typing `python setup_env.py venv` or `python setup_env.py base` skips the menu
    if len(sys.argv) > 1:
        answer = sys.argv[1].strip().lower()
    else:
        print()
        print("How do you want to install Pygame?")
        print()
        print("  1) In a virtual environment (.venv) inside this folder   [recommended]")
        print("     A private Python just for this game. Nothing else on your")
        print("     computer changes.")
        print()
        print("  2) Into your base Python (the one listed above)")
        print("     Choose this if you've been installing all your libraries into")
        print("     one Python and want to keep doing that.")
        print()
        answer = None

    while True:
        if answer in ("1", "venv", ".venv"):
            return "venv"
        if answer in ("2", "base"):
            return "base"
        if answer is not None:
            print(f'"{answer}" isn\'t one of the choices.')
        try:
            answer = input("Type 1 or 2, then press Enter: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            print("Setup cancelled. Nothing was changed.")
            sys.exit(1)


# ======================================================================
# Option 1: a virtual environment
# ======================================================================

def venv_python():
    """The path to the Python inside .venv."""
    if ON_WINDOWS:
        return os.path.join(VENV_FOLDER, "Scripts", "python.exe")
    return os.path.join(VENV_FOLDER, "bin", "python")


def venv_works():
    """True if .venv exists, its Python runs, and it has pip."""
    if not os.path.exists(venv_python()):
        return False
    worked, _ = run_quietly([venv_python(), "-m", "pip", "--version"])
    return worked


def setup_venv():
    if venv_works():
        print()
        print("Found a working .venv folder from before. Using it.")
    else:
        if os.path.exists(VENV_FOLDER):
            print()
            print("Found a .venv folder, but it doesn't work (it may have been copied")
            print("from another computer, or an earlier setup stopped partway).")
            print("Deleting it and making a fresh one...")
            shutil.rmtree(VENV_FOLDER, ignore_errors=True)

        print()
        print("Creating your virtual environment in the .venv folder...")
        result = subprocess.run([sys.executable, "-m", "venv", VENV_FOLDER])
        if result.returncode != 0 or not venv_works():
            shutil.rmtree(VENV_FOLDER, ignore_errors=True)
            stop("Python couldn't create the virtual environment. The message above\n"
                 "says why. You can also run this script again and choose option 2.")
        print("Done.")

    version = pygame_version(venv_python())
    if version is None:
        if not install_requirements(venv_python()):
            stop("Pygame didn't install. Check that you're connected to the internet,\n"
                 "then run this script again. The red text above says what went wrong.")
        version = pygame_version(venv_python())
        if version is None:
            stop("Pygame installed, but Python can't load it. Try deleting the .venv\n"
                 "folder and running this script again.")

    banner(f"ALL SET!  Pygame {version} is installed in your .venv")
    print()
    print("LAST STEP: tell VSCode to use your .venv")
    print()
    print("  If VSCode popped up a message asking to use the new environment,")
    print("  click Yes and you're done. Otherwise:")
    print()
    print(f"  1. Press {SHORTCUT}")
    print("  2. Type  Python: Select Interpreter  and press Enter")
    print("  3. Pick the one that mentions .venv")
    print()
    print("Then open stroop_smash.py and press the Run button to play!")
    print()
    print("Prefer the terminal? Open a new one (Terminal > New Terminal), then:")
    if ON_WINDOWS:
        print("    .venv\\Scripts\\activate")
    else:
        print("    source .venv/bin/activate")
    print("    python stroop_smash.py")
    print()


# ======================================================================
# Option 2: your base Python
# ======================================================================

def base_is_externally_managed():
    """True if this Python blocks pip (common with Homebrew Python on a Mac)."""
    if running_in_a_venv():
        return False
    marker = os.path.join(sysconfig.get_path("stdlib"), "EXTERNALLY-MANAGED")
    return os.path.exists(marker)


def setup_base():
    if running_in_a_venv():
        print()
        print("Heads up: the Python running this script is a virtual environment,")
        print("not your base Python. Pygame will be installed into it:")
        print("   ", sys.prefix)

    version = pygame_version(sys.executable)
    if version is not None:
        print()
        print("Pygame is already installed for this Python. Nothing to do!")
    else:
        if base_is_externally_managed():
            stop("This Python doesn't allow libraries to be installed into it directly\n"
                 "(this is common with Python from Homebrew). Run this script again and\n"
                 "choose option 1. A virtual environment avoids this problem.")
        if not install_requirements(sys.executable):
            stop("Pygame didn't install. Check that you're connected to the internet,\n"
                 "then run this script again. The red text above says what went wrong.\n"
                 "If it keeps failing, try option 1 instead.")
        version = pygame_version(sys.executable)
        if version is None:
            stop("Pygame installed, but Python can't load it. Try option 1 instead.")

    banner(f"ALL SET!  Pygame {version} is installed for this Python:")
    print("   ", sys.executable)
    print()
    print("Make sure VSCode uses this same Python. Look at the bottom-right corner")
    print("of VSCode while a .py file is open. If it shows a different Python:")
    print()
    print(f"  1. Press {SHORTCUT}")
    print("  2. Type  Python: Select Interpreter  and press Enter")
    print("  3. Pick the one whose path matches the line above")
    print()
    print("Then open stroop_smash.py and press the Run button to play!")
    print()


# ======================================================================
# Start here
# ======================================================================

def main():
    banner("Stroop Smash setup")
    version = sys.version.split()[0]
    print(f"Your Python:  {version}")
    print(f"Located at:   {sys.executable}")

    if sys.version_info < (3, 8):
        stop(f"Stroop Smash needs Python 3.8 or newer, but this is Python {version}.\n"
             "Install the newest Python from python.org, then run this script again.")

    if not os.path.exists(REQUIREMENTS):
        stop("requirements.txt is missing. It should be in the same folder as\n"
             "this script. Try downloading and unzipping the game again.")

    if choose_mode() == "venv":
        setup_venv()
    else:
        setup_base()


if __name__ == "__main__":
    main()

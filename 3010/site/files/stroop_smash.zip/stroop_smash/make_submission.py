"""
make_submission.py
==================
Zips up your game so you can submit it on Canvas.

The easiest way: open this file in VSCode and press the Run button.

It leaves out your .venv folder on purpose. That folder is large, and it
only works on your own computer, so there's no point submitting it.
You never need to change this file.
"""

import os
import re
import zipfile

GAME_FOLDER = os.path.dirname(os.path.abspath(__file__))
ASSIGNMENT = "coding_assignment_4"

SKIP_FOLDERS = {"__pycache__", ".git", ".vscode", ".idea"}
SKIP_FILES = {".DS_Store", "Thumbs.db"}


def is_environment(folder):
    """True if `folder` is a virtual environment (every venv has a pyvenv.cfg file)."""
    return os.path.exists(os.path.join(folder, "pyvenv.cfg"))


def clean_name(text):
    """'Mary Ann ' -> 'mary_ann'"""
    text = text.strip().lower()
    text = re.sub(r"[^\w-]+", "_", text)
    return text.strip("_")


def ask(question):
    while True:
        try:
            answer = clean_name(input(question))
        except (EOFError, KeyboardInterrupt):
            print()
            print("Cancelled. No zip file was made.")
            raise SystemExit(1)
        if answer:
            return answer
        print("Please type something.")


def main():
    print()
    last = ask("Your LAST name:  ")
    first = ask("Your FIRST name: ")

    zip_name = f"{last}_{first}_{ASSIGNMENT}.zip"
    zip_path = os.path.join(GAME_FOLDER, zip_name)
    top_folder = os.path.basename(GAME_FOLDER)

    file_count = 0
    csv_count = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zip_file:
        for folder, subfolders, files in os.walk(GAME_FOLDER):
            # Skip environments and clutter (changing `subfolders` tells os.walk not to go in)
            subfolders[:] = sorted(
                name for name in subfolders
                if name not in SKIP_FOLDERS and not is_environment(os.path.join(folder, name))
            )
            for name in sorted(files):
                if name in SKIP_FILES or name.endswith(".zip") or name.endswith(".pyc"):
                    continue
                full_path = os.path.join(folder, name)
                inside_zip = os.path.join(top_folder, os.path.relpath(full_path, GAME_FOLDER))
                zip_file.write(full_path, inside_zip)
                file_count += 1
                if name.endswith(".csv"):
                    csv_count += 1

    size_kb = os.path.getsize(zip_path) / 1024
    print()
    print("Done! Your zip file is ready:")
    print("   ", zip_path)
    print(f"    ({file_count} files, {size_kb:.0f} KB)")
    print()
    print("Upload it to Canvas, along with your screenshots and write-up.")
    print("(It's also in VSCode's file explorer, inside your stroop_smash folder.)")

    if csv_count == 0:
        print()
        print("Heads up: you don't have any game data yet (no CSV files in the data")
        print("folder). Play at least one full game, then run this script again.")
    print()


if __name__ == "__main__":
    main()

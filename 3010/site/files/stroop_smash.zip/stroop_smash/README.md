# Stroop Smash

A Stroop-effect game built with Pygame, for Coding Assignment 4.

## How to play

1. Open this folder in VSCode (`File > Open Folder...`).
2. **First time only:** open `setup_env.py` and press the Run button. Choose
   `1` (a virtual environment, recommended) or `2` (your base Python).
   If you chose `1`, tell VSCode to use it: `Ctrl+Shift+P` (Mac: `Cmd+Shift+P`)
   > `Python: Select Interpreter` > pick `.venv`.
3. Open `stroop_smash.py` and press the Run button.

A color word appears. Press the key for the **ink color**, not the word.
Press `Esc` at any time to quit.

## What's in this folder

| File | What it does |
|---|---|
| `stroop_smash.py` | **Run this one.** The game loop: the "director" of the game. |
| `settings.py` | Every setting: colors, keys, timing, number of trials. |
| `trials.py` | What a trial is, and how the list of trials is built. |
| `scoring.py` | How many points each answer is worth. |
| `display.py` | Everything drawn on the screen. |
| `results.py` | The end-of-game summary, and saving your data. |
| `setup_env.py` | Helper: installs Pygame. Run it once, before you play. |
| `requirements.txt` | The list of libraries `setup_env.py` installs. |
| `make_submission.py` | Helper: zips your game for Canvas (leaving out `.venv`). |
| `data/` | Created when you finish a game. One CSV file per game. |
| `.venv/` | Created by `setup_env.py` if you choose option 1. |

Look for comments that start with `>>> OPTION`: those mark the spots each
assignment option asks you to change.

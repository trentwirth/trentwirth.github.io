# Stroop Smash

A Stroop-effect game built with Pygame, for Coding Assignment 4.

## How to play

1. Install Pygame (once): `pip install pygame`
2. Open this folder in VSCode (`File > Open Folder...`).
3. Open `stroop_smash.py` and press the Run button, or type this in the terminal:

```
python stroop_smash.py
```

A color word appears. Press the key for the **ink color**, not the word.
Press `Esc` at any time to quit.

## What's in this folder

| File | What it does |
|---|---|
| `stroop_smash.py` | **Run this one.** The game loop: the "director" of the game. |
| `settings.py` | Every setting: colors, keys, timing, number of trials. |
| `trials.py` | What a trial is, and how the list of trials is built. |
| `scoring.py` | How many points each answer is worth. |
| `display.py` | Everything drawn on the screen. |
| `results.py` | The end-of-game summary, and saving your data. |
| `data/` | Created when you finish a game. One CSV file per game. |

Look for comments that start with `>>> OPTION`: those mark the spots each
assignment option asks you to change.

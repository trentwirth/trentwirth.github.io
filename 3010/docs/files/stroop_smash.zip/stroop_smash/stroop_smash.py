"""
stroop_smash.py
===============
RUN THIS FILE TO PLAY STROOP SMASH!

    python stroop_smash.py

This file is the "director". It runs the game loop and asks the other
files to do the detailed work:

    settings.py  -> every setting (colors, timing, number of trials)
    trials.py    -> what a trial is, and how the list of trials is built
    scoring.py   -> how many points each answer is worth
    display.py   -> everything drawn on the screen
    results.py   -> the end-of-game summary, and saving your data to a CSV
"""

import sys

import pygame

import settings
from trials import make_trials
from scoring import points_for_trial
from display import GameDisplay
from results import summarize_results, save_results_csv


class GameState:
    """Everything about the current game that changes while you play."""

    def __init__(self, total_trials):
        self.score = 0
        self.trial_number = 0
        self.total_trials = total_trials

        # >>> OPTION 3 (Lives): add a lives attribute here.

        # >>> OPTION 4 (Beat the Clock): add a time limit attribute here.


# ======================================================================
# Small helper functions
# ======================================================================

def quit_if_asked(event):
    """Close the game if the player clicks the window's X or presses Escape."""
    if event.type == pygame.QUIT:
        pygame.quit()
        sys.exit()
    if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
        pygame.quit()
        sys.exit()


def wait(ms, clock):
    """Pause for `ms` milliseconds, while still letting the player quit."""
    start = pygame.time.get_ticks()
    while pygame.time.get_ticks() - start < ms:
        for event in pygame.event.get():
            quit_if_asked(event)
        clock.tick(60)


def wait_for_space(clock):
    """Pause until the player presses the space bar."""
    while True:
        for event in pygame.event.get():
            quit_if_asked(event)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                return
        clock.tick(60)


def key_to_color(key_name):
    """Turn a key like 'r' into a color name like 'RED'.

    Returns None if the key doesn't belong to any color.
    """
    for color_name, info in settings.COLORS.items():
        if info["key"].lower() == key_name:
            return color_name
    return None


def check_settings():
    """Catch common mistakes in settings.py and explain them in plain English."""
    problems = []

    if len(settings.COLORS) < 2:
        problems.append("COLORS needs at least 2 colors.")

    keys_used = {}
    for color_name, info in settings.COLORS.items():
        if "rgb" not in info or "key" not in info:
            problems.append(f'{color_name} needs both an "rgb" and a "key".')
            continue

        rgb = info["rgb"]
        if not isinstance(rgb, (tuple, list)) or len(rgb) != 3:
            problems.append(f"{color_name}: rgb should be three numbers in parentheses, "
                            f"like (255, 0, 0).")
        else:
            for value in rgb:
                if not isinstance(value, int) or value < 0 or value > 255:
                    problems.append(f"{color_name}: each rgb number must be a whole number "
                                    f"from 0 to 255 (found {value}).")

        key = str(info["key"]).lower()
        if len(key) != 1:
            problems.append(f'{color_name}: the key should be ONE letter or number, '
                            f'like "r" (found "{info["key"]}").')
        elif key in keys_used:
            problems.append(f'{color_name} and {keys_used[key]} both use the key "{key}". '
                            f'Every color needs its own key.')
        else:
            keys_used[key] = color_name

    if len(problems) > 0:
        print("\nStroop Smash found a problem in settings.py:\n")
        for problem in problems:
            print("  -", problem)
        print("\nFix the problem, save settings.py, and run the game again.\n")
        sys.exit()


# ======================================================================
# One trial
# ======================================================================

def run_trial(trial, display, clock, state):
    """Show one word and wait for the player's answer."""

    # Step 1: show the fixation cross for a moment
    display.clear()
    display.draw_hud(state)
    display.draw_fixation()
    display.update()
    wait(settings.FIXATION_MS, clock)

    # Throw away any keys pressed too early, before the word appeared
    pygame.event.clear(pygame.KEYDOWN)

    # Step 2: show the colored word and start the stopwatch
    display.clear()
    display.draw_hud(state)
    display.draw_stimulus(trial)
    display.update()
    start_time = pygame.time.get_ticks()

    # Step 3: wait until the player presses one of the color keys
    waiting = True
    while waiting:
        for event in pygame.event.get():
            quit_if_asked(event)
            if waiting and event.type == pygame.KEYDOWN:
                color_chosen = key_to_color(pygame.key.name(event.key))
                if color_chosen is not None:
                    rt_ms = pygame.time.get_ticks() - start_time
                    trial.record_response(color_chosen, rt_ms)
                    waiting = False

        # >>> OPTION 4 (Beat the Clock): check the time limit here.

        clock.tick(240)


# ======================================================================
# One full game
# ======================================================================

def play_game(display, clock):
    """Play one full game. Returns the final state, summary, and data file path."""
    trials = make_trials(settings.NUM_TRIALS)
    state = GameState(total_trials=len(trials))

    display.clear()
    display.draw_instructions()
    display.update()
    wait_for_space(clock)

    for trial in trials:
        state.trial_number += 1
        run_trial(trial, display, clock, state)

        trial.points = points_for_trial(trial)
        state.score += trial.points

        # >>> OPTION 3 (Lives): lose a life after a wrong answer.

        # >>> OPTION 4 (Beat the Clock): shrink the time limit after a correct answer.

        display.clear()
        display.draw_hud(state)
        display.draw_feedback(trial)
        display.update()
        wait(settings.FEEDBACK_MS, clock)

        # >>> OPTION 3 (Lives): end the game early when lives run out.

    summary = summarize_results(trials)
    saved_path = save_results_csv(trials)
    return state, summary, saved_path


def main():
    check_settings()
    pygame.init()
    display = GameDisplay()
    clock = pygame.time.Clock()

    while True:
        state, summary, saved_path = play_game(display, clock)

        title = "Game complete!"
        # >>> OPTION 3 (Lives): show "Game Over!" if the player ran out of lives.

        display.clear()
        display.draw_end_screen(summary, state.score, title, saved_path)
        display.update()
        wait_for_space(clock)   # SPACE plays again, ESC quits


if __name__ == "__main__":
    main()

"""
scoring.py
==========
How many points each answer is worth.

>>> OPTION 2 (Scoring): this file is all yours. Change the rules inside
    points_for_trial() and the whole game uses your new scoring system:
    the score in the corner, the "+10 points" message, and the end screen.
"""


def points_for_trial(trial):
    """Return how many points the player earns for one trial.

    Useful information about the trial:
        trial.correct    -> True if the player pressed the right key, False if not
        trial.rt_ms      -> reaction time in milliseconds, e.g. 642
                            (this is None if the player ran out of time)
        trial.congruent  -> True if the word matched its ink ("RED" in red)

    A positive number adds points. A negative number takes points away.
    """
    if trial.correct:
        return 1
    else:
        return 0

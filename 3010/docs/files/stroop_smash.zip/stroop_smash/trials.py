"""
trials.py
=========
What one Stroop trial is, and how the game builds a list of them.

A "trial" is one round of the game: one word appears, the player answers.
(This is the same word researchers use: an experiment is made of trials.)
"""

import random

import settings


class StroopTrial:
    """One word on the screen, plus everything about the player's answer."""

    def __init__(self, word, ink):
        self.word = word                  # the text shown, e.g. "RED"
        self.ink = ink                    # the color it's drawn in, e.g. "BLUE"
        self.congruent = (word == ink)    # True when the word matches its ink

        # These get filled in once the player answers:
        self.response = None      # the color the player picked, e.g. "BLUE"
        self.rt_ms = None         # reaction time in milliseconds
        self.correct = None       # True or False
        self.timed_out = False    # becomes True if the player runs out of time (Option 4)
        self.points = 0           # points earned on this trial (see scoring.py)

        # >>> OPTION 5 (Switch It Up): add a "rule" attribute here.

    def correct_answer(self):
        """Return the color name the player SHOULD press for this trial."""
        # >>> OPTION 5 (Switch It Up): change this so that trials using
        #     the "word" rule return the word instead of the ink.
        return self.ink

    def record_response(self, color_chosen, rt_ms):
        """Save the player's answer and check whether it was right."""
        self.response = color_chosen
        self.rt_ms = rt_ms
        self.correct = (color_chosen == self.correct_answer())

    def to_dict(self):
        """Package this trial as a dictionary. Each one becomes a row in the CSV."""
        return {
            "word": self.word,
            "ink": self.ink,
            "congruent": self.congruent,
            "response": self.response,
            "correct": self.correct,
            "rt_ms": self.rt_ms,
            "timed_out": self.timed_out,
            "points": self.points,
            # >>> OPTION 5 (Switch It Up): add the rule here so it gets saved too.
        }


def make_trials(num_trials):
    """Build a shuffled list of StroopTrial objects."""
    color_names = list(settings.COLORS.keys())
    num_congruent = round(num_trials * settings.PERCENT_CONGRUENT / 100)

    trials = []
    for i in range(num_trials):
        word = random.choice(color_names)

        if i < num_congruent:
            # Congruent trial: the word is printed in its own color
            ink = word
        else:
            # Incongruent trial: pick any color EXCEPT the word itself
            other_colors = [color for color in color_names if color != word]
            ink = random.choice(other_colors)

        trial = StroopTrial(word, ink)

        # >>> OPTION 5 (Switch It Up): decide here whether this trial
        #     uses the "word" rule.

        trials.append(trial)

    random.shuffle(trials)
    return trials

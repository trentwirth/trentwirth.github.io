"""
results.py
==========
Two jobs, both done after a game ends:

    summarize_results() - calculate accuracy, speed, and your Stroop effect
    save_results_csv()  - save every trial to a CSV file in the data folder

You don't need to change this file for any of the options, but it's worth
reading: it uses lists, dictionaries, and the csv module from Steps 13-14.
"""

import csv
import os
from datetime import datetime

import settings


def average(numbers):
    """Return the mean of a list of numbers, or None if the list is empty."""
    if len(numbers) == 0:
        return None
    return sum(numbers) / len(numbers)


def summarize_results(trials):
    """Return a dictionary of summary numbers for the trials that were played."""
    # Only count trials the player actually reached (a game can end early)
    played = [trial for trial in trials if trial.correct is not None]
    correct = [trial for trial in played if trial.correct]

    # Reaction times from CORRECT answers only, split by condition
    congruent_rts = [trial.rt_ms for trial in correct if trial.congruent]
    incongruent_rts = [trial.rt_ms for trial in correct if not trial.congruent]

    mean_congruent = average(congruent_rts)
    mean_incongruent = average(incongruent_rts)

    # The Stroop effect: how much SLOWER mismatched words were
    if mean_congruent is None or mean_incongruent is None:
        stroop_effect = None
    else:
        stroop_effect = mean_incongruent - mean_congruent

    if len(played) == 0:
        accuracy = None
    else:
        accuracy = len(correct) / len(played) * 100

    return {
        "trials_played": len(played),
        "accuracy": accuracy,
        "mean_rt_congruent": mean_congruent,
        "mean_rt_incongruent": mean_incongruent,
        "stroop_effect": stroop_effect,
    }


def save_results_csv(trials):
    """Save every played trial to a new CSV file. Returns the file's path."""
    played = [trial for trial in trials if trial.correct is not None]
    if len(played) == 0:
        return None

    # Save next to this file, inside the data folder (create it if needed)
    game_folder = os.path.dirname(os.path.abspath(__file__))
    data_folder = os.path.join(game_folder, settings.DATA_FOLDER)
    os.makedirs(data_folder, exist_ok=True)

    # A new file for every game, named with the date and time
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    file_path = os.path.join(data_folder, f"stroop_{timestamp}.csv")

    rows = []
    for number, trial in enumerate(played, start=1):
        row = {"trial_number": number}
        row.update(trial.to_dict())
        rows.append(row)

    with open(file_path, "w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    return file_path

"""
display.py
==========
Everything that gets DRAWN on the screen lives in this file.

The GameDisplay class owns the game window and the fonts. Each draw_...
method paints one piece of the picture. To show a new frame, the game:

    1. calls display.clear()          -> wipe the screen
    2. calls some draw_... methods    -> paint the pieces
    3. calls display.update()         -> show the finished frame

Screen coordinates start at the TOP-LEFT corner of the window:
x grows to the right, and y grows DOWNWARD.
"""

import os

import pygame

import settings


class GameDisplay:
    """The game window, plus methods for drawing each part of the game."""

    def __init__(self):
        size = (settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT)
        self.screen = pygame.display.set_mode(size)
        pygame.display.set_caption("Stroop Smash")

        # pygame.font.Font(None, size) uses pygame's built-in font
        self.word_font = pygame.font.Font(None, settings.WORD_FONT_SIZE)
        self.title_font = pygame.font.Font(None, settings.TITLE_FONT_SIZE)
        self.text_font = pygame.font.Font(None, settings.TEXT_FONT_SIZE)
        self.small_font = pygame.font.Font(None, settings.SMALL_FONT_SIZE)

        self.center_x = settings.WINDOW_WIDTH // 2
        self.center_y = settings.WINDOW_HEIGHT // 2

    # ==================================================================
    # Basic tools
    # ==================================================================

    def clear(self):
        """Wipe the whole screen with the background color."""
        self.screen.fill(settings.BACKGROUND_COLOR)

    def update(self):
        """Show everything drawn since the last clear()."""
        pygame.display.flip()

    def draw_text(self, text, font, color, x, y, align="center"):
        """Draw text at (x, y) and return the rectangle around it.

        align="center" puts the middle of the text at x.
        align="left"   puts the left edge of the text at x.
        align="right"  puts the right edge of the text at x.
        """
        image = font.render(text, True, color)
        rect = image.get_rect()
        rect.centery = y
        if align == "left":
            rect.left = x
        elif align == "right":
            rect.right = x
        else:
            rect.centerx = x
        self.screen.blit(image, rect)
        return rect

    def key_reminder_lines(self, per_line):
        """Build lines like 'R = RED     G = GREEN' from settings.COLORS."""
        labels = []
        for color_name, info in settings.COLORS.items():
            labels.append(f"{info['key'].upper()} = {color_name}")

        lines = []
        for start in range(0, len(labels), per_line):
            lines.append("      ".join(labels[start:start + per_line]))
        return lines

    # ==================================================================
    # During the game
    # ==================================================================

    def draw_hud(self, state):
        """The heads-up display: score, trial counter, and key reminder.

        `state` is the GameState object from stroop_smash.py, so anything
        stored in it (like state.score) can be shown here.
        """
        self.draw_text(f"Score: {state.score}", self.text_font,
                       settings.TEXT_COLOR, 24, 32, align="left")

        self.draw_text(f"Trial {state.trial_number} of {state.total_trials}", self.text_font,
                       settings.TEXT_COLOR, settings.WINDOW_WIDTH - 24, 32, align="right")

        # >>> OPTION 3 (Lives): show the number of lives here.

        # >>> OPTION 4 (Beat the Clock): show the time limit here.

        # Key reminder along the bottom of the screen
        lines = self.key_reminder_lines(per_line=4)
        y = settings.WINDOW_HEIGHT - 28 * len(lines)
        for line in lines:
            self.draw_text(line, self.small_font, settings.HINT_COLOR, self.center_x, y)
            y = y + 28

    def draw_fixation(self):
        """The '+' that appears before each word. Players look here."""
        self.draw_text("+", self.title_font, settings.TEXT_COLOR,
                       self.center_x, self.center_y)

    def draw_stimulus(self, trial):
        """Draw the colored word for one trial."""
        ink_rgb = settings.COLORS[trial.ink]["rgb"]
        word_rect = self.draw_text(trial.word, self.word_font, ink_rgb,
                                   self.center_x, self.center_y)

        # >>> OPTION 5 (Switch It Up): if this trial uses the "word" rule,
        #     draw a box around the word. word_rect is the rectangle around it.

    def draw_feedback(self, trial):
        """'Correct!', 'Oops!', or 'Too slow!' after each answer."""
        if trial.timed_out:
            headline = "Too slow!"
            detail = f"The answer was {trial.correct_answer()}"
        elif trial.correct:
            headline = "Correct!"
            detail = f"{trial.rt_ms} ms"
        else:
            headline = "Oops!"
            detail = f"The answer was {trial.correct_answer()}"

        self.draw_text(headline, self.title_font, settings.TEXT_COLOR,
                       self.center_x, self.center_y - 50)
        self.draw_text(detail, self.text_font, settings.TEXT_COLOR,
                       self.center_x, self.center_y + 10)

        # Show the points from scoring.py, like "+1 point" or "-5 points"
        if trial.points != 0:
            if abs(trial.points) == 1:
                unit = "point"
            else:
                unit = "points"
            if trial.points > 0:
                points_text = f"+{trial.points} {unit}"
            else:
                points_text = f"{trial.points} {unit}"
            self.draw_text(points_text, self.text_font, settings.HINT_COLOR,
                           self.center_x, self.center_y + 55)

    # ==================================================================
    # Before and after the game
    # ==================================================================

    def draw_instructions(self):
        """The start screen. Its text updates itself when you add colors."""
        color_names = list(settings.COLORS.keys())
        example_word = color_names[0]
        example_ink = color_names[1]
        example_rgb = settings.COLORS[example_ink]["rgb"]
        example_key = settings.COLORS[example_ink]["key"].upper()

        y = 60
        self.draw_text("STROOP SMASH", self.title_font, settings.TEXT_COLOR, self.center_x, y)
        y = y + 65

        lines = [
            "A color word will flash on the screen.",
            "Press the key for the INK color, not the word!",
            # >>> OPTION 5 (Switch It Up): add a line here explaining the box rule.
        ]
        for line in lines:
            self.draw_text(line, self.text_font, settings.TEXT_COLOR, self.center_x, y)
            y = y + 38

        # An example word, drawn in a different ink color
        y = y + 40
        self.draw_text(example_word, self.title_font, example_rgb, self.center_x, y)
        y = y + 50
        self.draw_text(f"This word says {example_word}, but the ink is {example_ink}, "
                       f"so you would press {example_key}.",
                       self.small_font, settings.HINT_COLOR, self.center_x, y)

        # The keys, built automatically from settings.COLORS
        y = y + 55
        for line in self.key_reminder_lines(per_line=3):
            self.draw_text(line, self.text_font, settings.TEXT_COLOR, self.center_x, y)
            y = y + 38

        self.draw_text("Be fast AND accurate.   Press SPACE to start.", self.text_font,
                       settings.TEXT_COLOR, self.center_x, settings.WINDOW_HEIGHT - 45)

    def draw_end_screen(self, summary, score, title, saved_path):
        """The results screen, with the player's very own Stroop effect."""
        y = 60
        self.draw_text(title, self.title_font, settings.TEXT_COLOR, self.center_x, y)
        y = y + 70
        self.draw_text(f"Score: {score}", self.text_font, settings.TEXT_COLOR, self.center_x, y)

        if summary["accuracy"] is None:
            accuracy_text = "--"
        else:
            accuracy_text = f"{summary['accuracy']:.0f}%"
        y = y + 40
        self.draw_text(f"Accuracy: {accuracy_text}", self.text_font,
                       settings.TEXT_COLOR, self.center_x, y)

        y = y + 55
        self.draw_text(f"Average time on matching words:  {format_ms(summary['mean_rt_congruent'])}",
                       self.text_font, settings.TEXT_COLOR, self.center_x, y)
        y = y + 38
        self.draw_text(f"Average time on mismatched words:  {format_ms(summary['mean_rt_incongruent'])}",
                       self.text_font, settings.TEXT_COLOR, self.center_x, y)

        y = y + 75
        effect = summary["stroop_effect"]
        if effect is None:
            self.draw_text("Not enough correct answers to measure your Stroop effect.",
                           self.text_font, settings.TEXT_COLOR, self.center_x, y)
        else:
            self.draw_text(f"Your Stroop effect: {effect:+.0f} ms", self.title_font,
                           settings.TEXT_COLOR, self.center_x, y)
            y = y + 45
            self.draw_text("(how much longer mismatched words took you, on correct answers)",
                           self.small_font, settings.HINT_COLOR, self.center_x, y)

        if saved_path is not None:
            short_path = os.path.join(settings.DATA_FOLDER, os.path.basename(saved_path))
            self.draw_text(f"Your data was saved to {short_path}", self.small_font,
                           settings.HINT_COLOR, self.center_x, settings.WINDOW_HEIGHT - 80)

        self.draw_text("SPACE = play again          ESC = quit", self.text_font,
                       settings.TEXT_COLOR, self.center_x, settings.WINDOW_HEIGHT - 40)


def format_ms(value):
    """Turn 612.4 into '612 ms', or None into '--'."""
    if value is None:
        return "--"
    return f"{value:.0f} ms"

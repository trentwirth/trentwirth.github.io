"""
settings.py
===========
Every setting for Stroop Smash lives in this file.

The other files all read from here, so when you change something in this
file, the whole game updates automatically. That's the power of keeping
settings in one place!
"""

# ------------------------------------------------------------------
# COLORS
# ------------------------------------------------------------------
# Each color in the game has two parts:
#   "rgb" -> how the ink looks on screen: (red, green, blue), each 0 to 255
#   "key" -> the keyboard key the player presses for that color
#
# The color's name (like "RED") is also the word that appears on screen.
#
# >>> OPTION 1 (New Colors): add your new colors to this dictionary.
#     Copy one line, paste it below the others, and change the name,
#     the rgb numbers, and the key.
COLORS = {
    "RED":   {"rgb": (235, 70, 70),   "key": "r"},
    "GREEN": {"rgb": (60, 200, 95),   "key": "g"},
    "BLUE":  {"rgb": (80, 140, 255),  "key": "b"},
}

# ------------------------------------------------------------------
# GAME LENGTH
# ------------------------------------------------------------------
NUM_TRIALS = 24           # how many words you see in one game
PERCENT_CONGRUENT = 50    # % of words shown in their own color ("RED" in red)

# ------------------------------------------------------------------
# TIMING  (milliseconds: 1000 ms = 1 second)
# ------------------------------------------------------------------
FIXATION_MS = 500         # how long the "+" shows before each word
FEEDBACK_MS = 800         # how long "Correct!" or "Oops!" stays on screen

# ------------------------------------------------------------------
# HOW THE GAME LOOKS
# ------------------------------------------------------------------
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
BACKGROUND_COLOR = (25, 25, 30)     # very dark gray
TEXT_COLOR = (235, 235, 235)        # off-white, used for all regular text
HINT_COLOR = (150, 150, 160)        # gray, used for the key reminder

WORD_FONT_SIZE = 130      # the big colored word
TITLE_FONT_SIZE = 72      # titles like "STROOP SMASH" and "Correct!"
TEXT_FONT_SIZE = 36       # regular text
SMALL_FONT_SIZE = 26      # small text

# ------------------------------------------------------------------
# DATA
# ------------------------------------------------------------------
DATA_FOLDER = "data"      # each game is saved as a CSV file in this folder

# ------------------------------------------------------------------
# YOUR NEW SETTINGS
# ------------------------------------------------------------------
# Options 3, 4, and 5 ask you to add a new setting or two. Put them here.
